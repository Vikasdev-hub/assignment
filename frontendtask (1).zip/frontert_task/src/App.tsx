import { Home } from './screen';

function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;
